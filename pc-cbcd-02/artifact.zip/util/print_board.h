#ifndef _PRINT_BOARD_HEADER
#define _PRINT_BOARD_HEADER

#define PRINT_BOARD_SIZE	15

void print_board(char board[PRINT_BOARD_SIZE][PRINT_BOARD_SIZE]);

#endif
