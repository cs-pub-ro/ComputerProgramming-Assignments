#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util/scrabble.h"
#include "util/print_board.h"

#define SIZE		15
#define ABC_SIZE	26

char letters_score[ABC_SIZE] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, \
				1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

void save_word(char board[SIZE][SIZE], char word[SIZE], int X, int Y, int direction) {
	for (unsigned int i = 0; i < strlen(word); i++) {
		board[Y][X] = word[i];
		if (direction == 0) {
			X++;
		} else {
			Y++;
		}
	}
}

int compute_word_score(char word[SIZE]) {
	int score = 0;
	for (unsigned int i = 0; i < strlen(word); i++) {
		score += letters_score[word[i] - 'A'];
	}

	return score;
}

char word_has_bonus1(char word[SIZE], char bonus[3]) {
	if (strstr(word, bonus) != NULL)
		return 1;

	return 0;
}

char word_has_bonus2(char word[SIZE], char bonus[3], int size) {
	if (word[size - 1] == bonus[1] && word[size - 2] == bonus[0])
		return 1;

	return 0;
}

int get_bonus(int X, int Y, char direction, char word[SIZE],
			char bonus1_str[3], char bonus2_str[3]) {
	int bonus = 1, size = strlen(word);
	char bonus1 = word_has_bonus1(word, bonus1_str);
	char bonus2 = word_has_bonus2(word, bonus2_str, size);

	for (int i = 0; i < size; i++) {
		if (bonus_board[Y][X] == 1 && bonus1)
			bonus *= 2;

		if (bonus_board[Y][X] == 2 && bonus2)
			bonus *= 3;

		if (direction == 0) {
			X++;
		} else {
			Y++;
		}
	}

	return bonus;
}

void solve_task1(char board[][SIZE]) {
	int num_words, X, Y, direction;
	char word[SIZE];

	scanf("%d", &num_words);
	for (int i = 0; i < num_words; i++) {
		scanf("%d %d %d %s", &Y, &X, &direction, word);
		save_word(board, word, X, Y, direction);
	}

	print_board(board);
}

void solve_task2() {
	int num_words, X, Y, direction, scores[2] = {0}, player = 0;
	char word[SIZE];

	scanf("%d", &num_words);
	for (int i = 0; i < num_words; i++) {
		scanf("%d %d %d %s", &Y, &X, &direction, word);
		scores[player] += compute_word_score(word);
		player = (player + 1) % 2;
	}

	printf("Player 1: %d Points\n", scores[0]);
	printf("Player 2: %d Points\n", scores[1]);
}

void solve_task3() {
	int num_words, X, Y, direction, scores[2] = {0}, player = 0;
	char word[SIZE], bonus1_str[3], bonus2_str[3];

	scanf("%s", bonus1_str);
	scanf("%s", bonus2_str);
	scanf("%d", &num_words);

	for (int i = 0; i < num_words; i++) {
		scanf("%d %d %d %s", &Y, &X, &direction, word);
		scores[player] += compute_word_score(word) * get_bonus(X, Y, direction, word, bonus1_str, bonus2_str);
		player = (player + 1) % 2;
	}

	printf("Player 1: %d Points\n", scores[0]);
	printf("Player 2: %d Points\n", scores[1]);
}

char word_used(char word[SIZE], char words_used[NUM_WORDS][SIZE], int size) {
	for (int i = 0; i < size; i++) {
		if (strcmp(word, words_used[i]) == 0) 
			return 1;
	}

	return 0;
}

char can_place_horizontally(char board[SIZE][SIZE], char word[SIZE], int X, int Y) {
	if (X + strlen(word) > SIZE) 
		return 0;

	for (unsigned int i = X + 1; i < X + strlen(word); i++)
		if (board[Y][i] != '.')
			return 0;

	return 1;
}

char can_place_vertically(char board[SIZE][SIZE], char word[SIZE], int X, int Y) {
	if (Y + strlen(word) > SIZE)
		return 0;

	for (unsigned int i = Y + 1; i < Y + strlen(word); i++)
		if (board[i][X] != '.')
			return 0;

	return 1;
}

char can_place_on_board(char board[][SIZE], char word[SIZE], char coordinates[3]) {
	for (int i = 0; i < SIZE; i++) {
		for (int j = 0; j < SIZE; j++) {
			if (board[i][j] != word[0])
				continue;

			if (can_place_horizontally(board, word, j, i)) {
				char tmp_coordinates[] = {j, i, 0};
				memcpy(coordinates, tmp_coordinates, sizeof(tmp_coordinates));
				return 0;
			}

			if (can_place_vertically(board, word, j, i)) {
				char tmp_coordinates[] = {j, i, 1};
				memcpy(coordinates, tmp_coordinates, sizeof(tmp_coordinates));
				return 1;
			}
		}
	}

	return -1;
}

void solve_task4(char board[][SIZE]) {
	int num_words, X, Y, direction;
	char used_words[NUM_WORDS][SIZE];
	char bonus1_str[3], bonus2_str[3], coordinates[3] = {0};

	scanf("%s", bonus1_str);
	scanf("%s", bonus2_str);
	scanf("%d", &num_words);

	for (int i = 0; i < num_words; i++) {
		scanf("%d %d %d %s", &Y, &X, &direction, used_words[i]);
		save_word(board, used_words[i], X, Y, direction);
	}

	for (int i = 0; i < NUM_WORDS; i++) {
		if (word_used(words[i], used_words, num_words))
			continue;

		if (can_place_on_board(board, words[i], coordinates) != -1) {
			save_word(board, words[i], coordinates[0],
					coordinates[1], coordinates[2]);
			break;
		}
	}

	print_board(board);
}

void solve_task5(char board[][SIZE]) {
	int num_words, X, Y, direction, scores[2] = {0};
        int player = 0, index = -1, score = 0;
	char used_words[NUM_WORDS][SIZE], bonus1_str[3], bonus2_str[3], 
	     	final_coordinates[3], coordinates[3];
	
	scanf("%s", bonus1_str);
	scanf("%s", bonus2_str);
	scanf("%d", &num_words);

	for (int i = 0; i < num_words; i++) {
		scanf("%d %d %d %s", &Y, &X, &direction, used_words[i]);
		save_word(board, used_words[i], X, Y, direction);

		scores[player] += compute_word_score(used_words[i]) *
				get_bonus(X, Y, direction, used_words[i], bonus1_str, bonus2_str);
		player = (player + 1) % 2;
	}

	for (int i = 0; i < NUM_WORDS; i++) {
		if (word_used(words[i], used_words, num_words))
			continue;

		if (can_place_on_board(board, words[i], coordinates) != -1) {
			int tmp_score = compute_word_score(words[i]) * 
				get_bonus(coordinates[0], coordinates[1], coordinates[2], 
						words[i], bonus1_str, bonus2_str);	
			if (tmp_score > score) {
				memcpy(final_coordinates, coordinates, sizeof(coordinates));
				score = tmp_score;
				index = i;
			}
		}
	}

	if (scores[1] + score >= scores[0]) {
		save_word(board, words[index], final_coordinates[0], 
				final_coordinates[1], final_coordinates[2]);
		print_board(board);
	} else {
		printf("Fail!");
	}
}

void solve_task6(char board[][SIZE]) {
	int num_words, X, Y, direction, scores[2] = {0}, index, score;
	char used_words[NUM_WORDS][SIZE], bonus1_str[3], bonus2_str[3], 
	     	final_coordinates[3], coordinates[3];
	
	scanf("%s", bonus1_str);
	scanf("%s", bonus2_str);
	scanf("%d", &num_words);

	for (int i = 0; i < num_words; i++) {
		score = 0;
		scanf("%d %d %d %s", &Y, &X, &direction, used_words[i]);
		save_word(board, used_words[i], X, Y, direction);

		scores[0] += compute_word_score(used_words[i]) *
				get_bonus(X, Y, direction, used_words[i], bonus1_str, bonus2_str);
	
		for (int i = 0; i < NUM_WORDS; i++) {
			if (word_used(words[i], used_words, num_words))
				continue;

			if (can_place_on_board(board, words[i], coordinates) != -1) {
				int tmp_score = compute_word_score(words[i]) * 
					get_bonus(coordinates[0], coordinates[1], coordinates[2], 
						words[i], bonus1_str, bonus2_str);	
				if (tmp_score > score) {
					memcpy(final_coordinates, coordinates, sizeof(coordinates));
					score = tmp_score;
					index = i;
				}
			}
		}
		
		save_word(board, words[index], final_coordinates[0], 
					final_coordinates[1], final_coordinates[2]);
		scores[1] += score;
	}

	print_board(board);
	if (scores[0] > scores[1]) {
		printf("Player 1 Won!\n");
	} else {
		printf("Player 2 Won!\n");
	}
}

int main(void) {
	char board[SIZE][SIZE];
	int task;

	memset(board, '.', SIZE * SIZE);
	scanf("%d", &task);
	
	switch (task) {
	case 0:
		print_board(board);
		break;
	case 1:
		solve_task1(board);
		break;
	case 2:
		solve_task2();
		break;
	case 3:
		solve_task3();
		break;
	case 4:
		solve_task4(board);
		break;
	case 5:
		solve_task5(board);
		break;
	case 6:
		solve_task6(board);
		break;
	default:
		printf("Wrong task number!\n");
	}

	return 0;
}